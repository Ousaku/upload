package com.atm.springmvc.demo.controller;

import com.atm.springmvc.demo.model.UrlModel;
import com.atm.springmvc.demo.model.UserModel;
import com.atm.springmvc.demo.service.UserService;

import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;

/**
 * Created by hudingchen on 18/07/2017.
 */
@RestController
@RequestMapping("/pa")
public class UserController {

    @Autowired
    private UserService userService;


    @RequestMapping(value = "/papapa", method = RequestMethod.POST)
    public Object papapa(@RequestBody UrlModel model) throws IOException, ParserConfigurationException, SAXException, JDOMException {


        HashMap<String, Object> resultDic = new HashMap<String, Object>();

        resultDic.put("data", "a");
        return resultDic;

    }

}
