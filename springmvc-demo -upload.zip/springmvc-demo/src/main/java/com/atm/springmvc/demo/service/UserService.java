package com.atm.springmvc.demo.service;

import com.atm.springmvc.demo.dao.UserDao;
import com.atm.springmvc.demo.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by hudingchen on 19/07/2017.
 */
@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    public List<UserModel> getAllUserList() {
        return userDao.getAllUserList();
    }

    public UserModel findUserById(UserModel userModel) {
        return userDao.findUserById(userModel);
    }

    public UserModel login(UserModel userModel) {
        UserModel user = userDao.findUserById(userModel);
        if (user == null || !user.getPassword().equals(userModel.getPassword())) {
            return new UserModel();
        }

        return user;
    }
}
