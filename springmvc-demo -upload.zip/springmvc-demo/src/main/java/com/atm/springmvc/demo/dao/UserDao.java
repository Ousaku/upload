package com.atm.springmvc.demo.dao;

import java.util.List;

import com.atm.springmvc.demo.model.UserModel;

public interface UserDao {
	List<UserModel> getAllUserList();

	UserModel findUserById(UserModel userModel);

	void insertUser(UserModel user);
}
