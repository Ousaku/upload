package com.atm.springmvc.demo.model;

import java.io.Serializable;

public class UrlModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String url;

    private String result;

    private String source;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
