
package com.atm.springmvc.demo.controller;
import cn.stylefeng.roses.core.util.ToolUtil;
import com.atm.springmvc.demo.model.UrlModel;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;


@Controller
@RequestMapping("upload")
public class UploadController {
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ModelAndView init() {
        System.out.println("upload!!");
        ModelAndView mav = new ModelAndView();
        //mav.addObject("form", form);
        mav.setViewName("upload");
        return mav;
    }




    /**
     * 上传图片
     */
    @RequestMapping(method = RequestMethod.POST, path = "/uploadImage")
    @ResponseBody
    public ResponseEntity<String> upload(@RequestPart("file") MultipartFile picture) {

        String pictureName = UUID.randomUUID().toString() + "." + ToolUtil.getFileSuffix(picture.getOriginalFilename());
        try {
            String fileSavePath = "/Users/wangce/Desktop/upload/";
            picture.transferTo(new File(fileSavePath + pictureName));
            String a = "";
            return ResponseEntity.status(HttpStatus.CREATED).body(null);
        } catch (Exception e) {
            //抛出异常

        }
        return null;
    }
}
