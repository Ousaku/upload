package com.atm.springmvc.demo.controller;

import com.atm.springmvc.demo.model.UrlModel;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * Created by hudingchen on 18/07/2017.
 */
@Controller
@RequestMapping("hello")
public class HelloController {
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ModelAndView init() {
        System.out.println("home!!");
        ModelAndView mav = new ModelAndView();
        //mav.addObject("form", form);
        mav.setViewName("hello");
        return mav;
    }


}
